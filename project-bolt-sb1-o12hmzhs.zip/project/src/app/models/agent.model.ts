export interface Agent {
  id: string;
  name: string;
  systemPrompt: string;
  model: string;
  createdAt: Date;
}